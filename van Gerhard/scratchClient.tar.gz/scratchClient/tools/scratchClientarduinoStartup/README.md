# scratchClientArduinoStartup
startup tool for arduinoUNO related scratchClient systems.

scratchClient supports an adapter for arduinoUNO. 
In a school environment using different configurations, this tool provides an easy GUI based start of scratchClient.