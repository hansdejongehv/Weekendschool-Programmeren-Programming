#
# NanoManager 
# allows to open connections to usbserial and to check the received IDENT in a singleton
#
