A sample for mqtt etween two computers

device_0: RPi with GPIO17 button to GND

device_1: RPI or computer
 